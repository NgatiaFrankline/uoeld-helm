{{/* Common Frappe volumes definition */}}

{{- define "x.frappe.volumeMounts" -}}
volumeMounts:
  - name: frappe-bench-drive
    mountPath: /home/frappe/frappe-bench
  - name: backup-drive
    mountPath: /backup
  - name: frappe-archive-drive
    mountPath: /archive
  - name: frappe-logs-drive
    mountPath: /logs
  - name: bench-init-commands
    mountPath: /conf/benchinit_commands.conf
    subPath: benchinit_commands.conf
  - name: ssh-key
    mountPath: /home/frappe/.ssh
    readOnly: true
{{- end }}

{{- define "x.frappe.volumes" -}}
volumes:
  - name: frappe-bench-drive
    hostPath:
      path: {{ .Values.hostPath.frappeBench }}
      type: DirectoryOrCreate
  - name: frappe-archive-drive
    hostPath:
      path: {{ .Values.hostPath.archive }}
      type: DirectoryOrCreate
  - name: frappe-logs-drive
    hostPath:
      path: {{ .Values.hostPath.logs }}
      type: DirectoryOrCreate
  - name: backup-drive
    hostPath:
      path: {{ .Values.hostPath.backup }}
      type: DirectoryOrCreate
  - name: bench-init-commands
    configMap:
      name: bench-init-config
      defaultMode: 0775
      items:
        - key: COMMANDS
          path: benchinit_commands.conf
  - name: ssh-key
    secret:
      secretName: my-git-key-secret
      defaultMode: 0440
      items:
        - key: SSH_CONFIG
          path: config
        - key: MY_GIT_KEY
          path: my_git_key
        - key: MY_GIT_KEY_PUB
          path: my_git_key.pub
{{- end }}
